package it.marrocco.h2ejbdemo;

import it.marrocco.h2ejbdemo.ejb.HtmlElements;

import java.io.*;
import javax.naming.NamingException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "searchMatriculation", value = "/searchMatriculation")
public class SearchMatriculationServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int matriculation;
        try {
            matriculation = Integer.parseInt(request.getParameter("matriculation"));
        } catch (NumberFormatException e) {
            response.sendRedirect("");
            return;
        }
        boolean showStudentPage = request.getParameter("studentPage") != null;
        boolean showAdvisoryPage = request.getParameter("advisoryPage") != null;

        String html = "";
        String name;
        try {
            name = "java:module/HtmlElementsEJB!it.marrocco.h2ejbdemo.ejb.HtmlElements";
            HtmlElements htmlElementsEJB = (HtmlElements) ServiceLocator.getService(name);

            if (showStudentPage) html += htmlElementsEJB.getStudentPageElement(matriculation);
            if (showAdvisoryPage) html += htmlElementsEJB.getAdvisoryPageElement(matriculation);
        } catch (NamingException e) {
            html += "<h1>" + e.getMessage() + "</h1>";
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Matriculation "+matriculation+"</title></head><body>");
        out.println(html);
        out.println("<a href='index.jsp'>Go back</a>");
        out.println("</body></html>");
        out.close();
    }
}