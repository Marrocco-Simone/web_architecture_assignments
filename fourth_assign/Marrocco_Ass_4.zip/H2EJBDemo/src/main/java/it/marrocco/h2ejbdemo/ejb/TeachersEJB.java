package it.marrocco.h2ejbdemo.ejb;

import it.marrocco.h2ejbdemo.ServiceLocator;
import it.marrocco.h2ejbdemo.entities.StudentCourseEntity;
import it.marrocco.h2ejbdemo.entities.TeacherEntity;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

@Stateless
@Local(Teachers.class)
public class TeachersEJB implements Teachers {
    @PersistenceContext(unitName="default")
    private EntityManager entityManager;

    Context ctx;
    StudentCourse studentCourseEJB;
    public void ejbCreate() {
        try {
            studentCourseEJB = (StudentCourse) ServiceLocator.getService("java:module/StudentCourseEJB!it.marrocco.h2ejbdemo.ejb.StudentCourse");
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<TeacherEntity> getStudentTeachers(int matriculation) {
        List<StudentCourseEntity> sc = studentCourseEJB.getStudentCourses(matriculation);
        if (sc == null) return null;
        List<TeacherEntity> t = new ArrayList<>();
        for (StudentCourseEntity s : sc) {
            t.add(s.getCourse().getTeacher());
        }
        return t;
    }
}
