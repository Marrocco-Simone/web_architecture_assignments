package it.marrocco.h2ejbdemo.ejb;

import it.marrocco.h2ejbdemo.entities.StudentCourseEntity;
import it.marrocco.h2ejbdemo.entities.StudentEntity;
import it.marrocco.h2ejbdemo.entities.TeacherEntity;

import java.util.List;

public interface Facade {
    StudentEntity getSingleStudent(int matriculation);
    List<StudentCourseEntity> getStudentCourses(int matriculation);
    List<TeacherEntity> getStudentTeachers(int matriculation);
}
