package it.marrocco.h2ejbdemo.ejb;

import it.marrocco.h2ejbdemo.entities.StudentCourseEntity;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Stateless
@Local(StudentCourse.class)
public class StudentCourseEJB implements StudentCourse {
    @PersistenceContext(unitName="default")
    private EntityManager entityManager;

    @Override
    public List<StudentCourseEntity> getStudentCourses(int matriculation) {
        try {
            Query q = entityManager.createQuery(
                "From StudentCourseEntity where student.matriculation = " + matriculation
            );
            List<StudentCourseEntity> sc = q.getResultList();
            if (sc.isEmpty()) System.out.println("StudentCourse is empty");
            return sc;
        } catch (NoResultException e) {
            System.out.println("StudentCourse was not found");
            return null;
        }
    }
}
