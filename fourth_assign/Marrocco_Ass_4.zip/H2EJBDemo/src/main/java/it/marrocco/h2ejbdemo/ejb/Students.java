package it.marrocco.h2ejbdemo.ejb;

import it.marrocco.h2ejbdemo.entities.StudentEntity;

public interface Students {
    StudentEntity getSingleStudent(int matriculation);
}
