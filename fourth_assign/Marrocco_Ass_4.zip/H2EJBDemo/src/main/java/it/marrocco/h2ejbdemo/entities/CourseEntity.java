package it.marrocco.h2ejbdemo.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "COURSE")
public class CourseEntity implements Serializable {
    @Id
    @Column(name = "NAME", nullable = false)
    private String name;

    // why JoinColumn: https://stackoverflow.com/questions/4121485/columns-not-allowed-on-a-manytoone-property
    @JoinColumn(name = "TEACHER", nullable = false)
    @OneToOne(cascade = {CascadeType.REMOVE})
    private TeacherEntity teacher;

    public CourseEntity() {}
    public CourseEntity(String name, TeacherEntity teacher) {
        this.name = name;
        this.teacher = teacher;
    }


    public String getName() {return name;}
    public void setName(String name) {this.name = name;}

    public TeacherEntity getTeacher() {return teacher;}
    public void setTeacher(TeacherEntity teacher) {this.teacher = teacher;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CourseEntity that = (CourseEntity) o;
        return name.equals(that.name) && teacher.equals(that.teacher);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, teacher);
    }
}
