package it.marrocco.h2ejbdemo.ejb;

import it.marrocco.h2ejbdemo.entities.StudentCourseEntity;

import java.util.List;

public interface StudentCourse {
    List<StudentCourseEntity> getStudentCourses(int matriculation);
}
