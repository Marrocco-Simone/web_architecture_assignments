package it.marrocco.h2ejbdemo.ejb;

import it.marrocco.h2ejbdemo.entities.TeacherEntity;

import java.util.List;

public interface Teachers {
    List<TeacherEntity> getStudentTeachers(int matriculation);
}
