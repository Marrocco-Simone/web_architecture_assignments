package it.marrocco.h2ejbdemo.ejb;

import it.marrocco.h2ejbdemo.entities.StudentEntity;

public interface HtmlElements {
    String formatStudentEntity(StudentEntity s);
    String getStudentPageElement(int matriculation);
    String getAdvisoryPageElement(int matriculation);
}
