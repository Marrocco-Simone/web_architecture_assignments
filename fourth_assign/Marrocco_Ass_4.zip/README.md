The wildfly server is in H2EJBDemo, while the client Tomcat is in MarroccoAss4Client. For the first one, unfortunately I started working on top of the demo we made in class and the project breaks if I try to change the name of the folder.

Marrocco Simone

