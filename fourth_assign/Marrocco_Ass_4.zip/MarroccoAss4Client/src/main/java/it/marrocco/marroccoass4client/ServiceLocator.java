package it.marrocco.marroccoass4client;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.HashMap;
import java.util.Properties;

public class ServiceLocator {
    private static HashMap<String, Object> cache;

    static {
        cache = new HashMap<String, Object>();
    }

    private static Properties getJndiProperties() {
        Properties jndiProperties=new Properties();
        jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.wildfly.naming.client.WildFlyInitialContextFactory");
        jndiProperties.put(Context.PROVIDER_URL,"http-remoting://localhost:8080");
        return jndiProperties;
    }

    public static Object getService(String jndiName) throws NamingException {
        Object service = cache.get(jndiName);
        if (service == null) {
            InitialContext context = new InitialContext(getJndiProperties());
            service = context.lookup(jndiName);
            cache.put(jndiName, service);
        }
        return service;
    }
}
