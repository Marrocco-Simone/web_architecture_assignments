package it.marrocco.marroccoass4client.ejb;

import it.marrocco.marroccoass4client.ServiceLocator;
import it.marrocco.marroccoass4client.entities.StudentCourseEntity;
import it.marrocco.marroccoass4client.entities.StudentEntity;
import it.marrocco.marroccoass4client.entities.TeacherEntity;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.naming.NamingException;
import java.util.List;

public class HtmlElementsEJB implements HtmlElements{
    Facade facadeEJB;
    public HtmlElementsEJB() {
        try {
            facadeEJB = (Facade) ServiceLocator.getService("ejb:/H2EJBDemo-1.0-SNAPSHOT/FacadeEJB!it.marrocco.h2ejbdemo.ejb.Facade");
        } catch (NamingException e) {
            System.out.println("Naming exception: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    @Override
    public String formatStudentEntity(StudentEntity s) {
        return "<h1>" + s.getSurname() + " " + s.getName() + " (" + s.getMatriculation() + ")</h1>";
    }

    @Override
    public String getStudentPageElement(int matriculation) {
        StudentEntity s = facadeEJB.getSingleStudent(matriculation);
        if (s == null) return "<h1>Student was not found</h1>";
        String html = formatStudentEntity(s);
        html += "<h2>Courses:</h2>";
        try {
            html += "<ul>";
            List<StudentCourseEntity> sc = facadeEJB.getStudentCourses(matriculation);
            if (sc == null) return "<h1>Error getting the Student Courses</h1>";
            for (StudentCourseEntity c : sc) {
                html += "<li>" + c.getCourse().getName();
                if(c.getGrade() != null)
                    html +=  " (grade = " + c.getGrade() + ")";
                html += "</li>";
            }
            html += "</ul>";
        } catch (Exception e ) {
            System.out.println("error: " + e.getMessage());
            html += "<h3>error<h3>";
        }
        return html;
    }

    @Override
    public String getAdvisoryPageElement(int matriculation) {
        StudentEntity s = facadeEJB.getSingleStudent(matriculation);
        if (s == null) return "<h1>Student was not found</h1>";
        String html = formatStudentEntity(s);
        html += "<h2>Advisors:</h2>";
        try {
            html += "<ul>";
            List<TeacherEntity> sc = facadeEJB.getStudentTeachers(matriculation);
            if (sc == null) return "<h1>Error getting the Student Teachers</h1>";
            for (TeacherEntity t : sc) {
                html += "<li>" + t.getSurname() + " " + t.getName() + "</li>";
            }
            html += "</ul>";
        } catch (Exception e ) {
            System.out.println("error: " + e.getMessage());
            html += "<h3>error<h3>";
        }
        return html;
    }
}
