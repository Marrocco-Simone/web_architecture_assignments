package it.marrocco.marroccoass4client.ejb;

import it.marrocco.marroccoass4client.entities.StudentCourseEntity;
import it.marrocco.marroccoass4client.entities.StudentEntity;
import it.marrocco.marroccoass4client.entities.TeacherEntity;

import javax.ejb.Remote;
import java.util.List;

@Remote
public interface Facade {
    StudentEntity getSingleStudent(int matriculation);
    List<StudentCourseEntity> getStudentCourses(int matriculation);
    List<TeacherEntity> getStudentTeachers(int matriculation);
}
