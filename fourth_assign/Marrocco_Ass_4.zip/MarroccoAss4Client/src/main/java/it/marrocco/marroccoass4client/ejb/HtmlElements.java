package it.marrocco.marroccoass4client.ejb;

import it.marrocco.marroccoass4client.entities.StudentEntity;

public interface HtmlElements {
    String formatStudentEntity(StudentEntity s);
    String getStudentPageElement(int matriculation);
    String getAdvisoryPageElement(int matriculation);
}
