package it.marrocco.marroccoass4client.entities;

import java.io.Serializable;
import java.util.Objects;

public class StudentCourseEntity implements Serializable {
    private StudentEntity student;
    private CourseEntity course;
    private Integer grade;

    public StudentEntity getStudent() {
        return student;
    }

    public void setStudent(StudentEntity student) {
        this.student = student;
    }

    public CourseEntity getCourse() {
        return course;
    }

    public void setCourse(CourseEntity course) {
        this.course = course;
    }

    public Integer getGrade() {
        return grade;
    }
    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StudentCourseEntity that = (StudentCourseEntity) o;
        return student.equals(that.student) && course.equals(that.course) && Objects.equals(grade, that.grade);
    }

    @Override
    public int hashCode() {
        return Objects.hash(student, course, grade);
    }
}
