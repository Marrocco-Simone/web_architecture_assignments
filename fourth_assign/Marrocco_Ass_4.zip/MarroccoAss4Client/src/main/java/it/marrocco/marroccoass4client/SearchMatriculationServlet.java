package it.marrocco.marroccoass4client;

import it.marrocco.marroccoass4client.ejb.HtmlElements;
import it.marrocco.marroccoass4client.ejb.HtmlElementsEJB;

import javax.naming.NamingException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "searchMatriculation", value = "/searchMatriculation")
public class SearchMatriculationServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int matriculation;
        try {
            matriculation = Integer.parseInt(request.getParameter("matriculation"));
        } catch (NumberFormatException e) {
            response.sendRedirect("");
            return;
        }
        boolean showStudentPage = request.getParameter("studentPage") != null;
        boolean showAdvisoryPage = request.getParameter("advisoryPage") != null;

        String html = "";
        try {
            HtmlElements htmlElementsEJB = new HtmlElementsEJB();

            if (showStudentPage) html += htmlElementsEJB.getStudentPageElement(matriculation);
            if (showAdvisoryPage) html += htmlElementsEJB.getAdvisoryPageElement(matriculation);
        } catch (Exception e) {
            System.out.println("Error in fetching data");
            html += "<h1>Error in fetching data</h1>";
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Matriculation "+matriculation+"</title></head><body>");
        out.println(html);
        out.println("<a href='index.jsp'>Go back</a>");
        out.println("</body></html>");
        out.close();
    }
}