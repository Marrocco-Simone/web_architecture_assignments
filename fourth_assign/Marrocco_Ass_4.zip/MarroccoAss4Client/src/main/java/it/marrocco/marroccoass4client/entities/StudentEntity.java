package it.marrocco.marroccoass4client.entities;

import java.io.Serializable;
import java.util.Objects;

public class StudentEntity implements Serializable {
    private Integer matriculation;
    private String name;
    private String surname;

    public StudentEntity() {}
    public StudentEntity(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    public Integer getMatriculation() {return matriculation;}
    public void setMatriculation(Integer matriculation) {this.matriculation = matriculation;}

    public String getName() {return name;}
    public void setName(String name) {this.name = name;}

    public String getSurname() {return surname;}
    public void setSurname(String surname) {this.name = surname;}
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StudentEntity that = (StudentEntity) o;
        return matriculation.equals(that.matriculation) && name.equals(that.name) && surname.equals(that.surname);
    }

    @Override
    public int hashCode() {
        return Objects.hash(matriculation, name, surname);
    }
}
