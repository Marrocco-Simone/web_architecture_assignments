export type Website = {
  ID: number;
  PersonID: number;
  WebSiteTypeID: number;
  WebURL: string;
  IsDefault: boolean;
};
