var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
//@ts-ignore
var n_rows = n_rows;
// get html references
var d = document;
var input = d.getElementById("modify-cell");
var label = d.getElementById("modify-cell-label");
var submit_button = d.getElementById("modify-cell-submit");
if (!(input && label && submit_button))
    throw new Error("Html file not correct format or you didn't import with 'defer'");
// * global variables
/** current cell selected */
var current_cell_id = "";
var url = "http://localhost:8080/Spreadsheet_war_exploded/server";
// const url = '/server';
/** data structure to save the data about the cells */
var cell_value_map = {};
initCellValueMap();
// * functions
/** initialize the cell_value_map by asking the server */
function initCellValueMap() {
    for (var i = 0; i < n_rows; i++)
        for (var j = 1; j <= n_rows; j++) {
            var letter = String.fromCharCode("A".charCodeAt(0) + i);
            cell_value_map[letter + j] = {
                formula: "",
                shown_value: ""
            };
        }
}
/**
 * function called when the cell is not clicked anymore,
 * either because a new one is clicked or the cell is double clicked.
 * If the formula changed, send the server a change cell request
 */
function resetClick() {
    var formula = input.value;
    input.value = "";
    input.disabled = true;
    label.textContent = "Select a cell to modify it";
    submit_button.disabled = true;
    var previous_cell = document.getElementById(current_cell_id);
    if (previous_cell) {
        previous_cell.style.outline = "0px solid black";
        previous_cell.textContent = cell_value_map[current_cell_id].shown_value;
        if (formula !== cell_value_map[current_cell_id].formula)
            serverParseFormula(formula);
    }
    current_cell_id = "";
}
/** enable the form input and button to modify the cell value */
function enableModify(cell_id) {
    input.disabled = false;
    input.name = "new_".concat(cell_id, "_value");
    input.focus();
    label.textContent = "Selected cell: ".concat(cell_id);
    submit_button.disabled = false;
}
/**
 * function called from a cell onclick event.
 * It changes the current_cell, by coloring it red and
 * enables input modification.
 */
function clickedCell(cell_id) {
    var previous_cell_id = current_cell_id;
    resetClick();
    if (cell_id === previous_cell_id)
        return;
    var current_cell = document.getElementById(cell_id);
    if (!current_cell)
        return;
    current_cell.style.outline = "5px solid green";
    var formula = cell_value_map[cell_id].formula;
    current_cell.textContent = formula;
    input.value = formula;
    current_cell_id = cell_id;
    enableModify(cell_id);
}
/** when something is typed in the input, changes the cell text to keep up */
function inputChanged() {
    var current_cell = document.getElementById(current_cell_id);
    if (current_cell) {
        current_cell.textContent = input.value;
    }
}
/**
 * when the input form is submitted, send data to the server.
 * It prevents default behaviour
 */
function submitInput(event) {
    event.preventDefault();
    var current_cell = document.getElementById(current_cell_id);
    if (current_cell) {
        resetClick();
    }
}
/** inform the server of a cell modification, then use modifyCells() */
function serverParseFormula(formula) {
    return __awaiter(this, void 0, void 0, function () {
        var server_req, res_json, res, e_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (formula.includes('"'))
                        return [2 /*return*/, alert('Invalid " character inside input')];
                    server_req = {
                        cell: current_cell_id,
                        formula: formula
                    };
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, fetch(url, {
                            method: "POST",
                            body: JSON.stringify(server_req)
                        })];
                case 2:
                    res_json = _a.sent();
                    return [4 /*yield*/, res_json.json()];
                case 3:
                    res = _a.sent();
                    if (res.success) {
                        console.log("POST request was OK");
                    }
                    else {
                        console.log("POST request ERROR: ".concat(res.reason));
                        alert("You made an invalid request\nReason: ".concat(res.reason));
                    }
                    return [3 /*break*/, 5];
                case 4:
                    e_1 = _a.sent();
                    console.error(e_1);
                    alert("Something went wrong!\nError sending changes: ".concat(e_1.message));
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    });
}
/** modify the cells as said from the server */
function modifyCells(res) {
    return __awaiter(this, void 0, void 0, function () {
        var _i, _a, c, cell_id, value, formula, cell, new_value;
        return __generator(this, function (_b) {
            if (!res.changes.length)
                return [2 /*return*/];
            console.table(res.changes);
            for (_i = 0, _a = res.changes; _i < _a.length; _i++) {
                c = _a[_i];
                cell_id = c.cell, value = c.value, formula = c.formula;
                cell = document.getElementById(cell_id);
                if (!cell)
                    continue;
                new_value = formula ? value : "";
                cell.textContent = new_value;
                cell_value_map[cell_id].shown_value = new_value;
                cell_value_map[cell_id].formula = formula;
            }
            return [2 /*return*/];
        });
    });
}
/** use EventSource to receive updates from the server */
function receivePushNotification() {
    var source = new EventSource(url);
    source.onopen = function () {
        console.log("eventsource opened");
    };
    source.onerror = function () {
        console.log("eventsource error, reloading...");
    };
    source.onmessage = function (event) {
        console.log("new update received");
        var res_json = event.data;
        var res = JSON.parse(res_json);
        modifyCells(res);
    };
    return source;
}
var source = receivePushNotification();
