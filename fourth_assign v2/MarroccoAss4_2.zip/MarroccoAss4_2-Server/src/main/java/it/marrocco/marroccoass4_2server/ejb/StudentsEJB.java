package it.marrocco.marroccoass4_2server.ejb;

import it.marrocco.marroccoass4_2server.entities.StudentEntity;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
@Local(Students.class)
public class StudentsEJB implements Students{
    @PersistenceContext(unitName="default")
    private EntityManager entityManager;

    @Override
    public StudentEntity getSingleStudent(int matriculation){
        try {
            Query q = entityManager.createQuery("From StudentEntity where matriculation = " + matriculation);
            StudentEntity s = (StudentEntity) (q.getSingleResult());
            return s;
        } catch (NoResultException e) {
            System.out.println("Student was not found");
            return null;
        }
    }
}
