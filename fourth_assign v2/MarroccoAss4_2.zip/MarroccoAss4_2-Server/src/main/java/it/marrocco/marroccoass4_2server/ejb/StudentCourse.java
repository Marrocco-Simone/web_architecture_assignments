package it.marrocco.marroccoass4_2server.ejb;

import it.marrocco.marroccoass4_2server.entities.StudentCourseEntity;

import java.util.List;

public interface StudentCourse {
    List<StudentCourseEntity> getStudentCourses(int matriculation);
}
