package it.marrocco.marroccoass4_2server.ejb;

import it.marrocco.marroccoass4_2server.entities.StudentCourseEntity;
import it.marrocco.marroccoass4_2server.entities.StudentEntity;
import it.marrocco.marroccoass4_2server.entities.TeacherEntity;

import java.util.List;

public interface Facade {
    StudentEntity getSingleStudent(int matriculation);
    List<StudentCourseEntity> getStudentCourses(int matriculation);
    List<TeacherEntity> getStudentTeachers(int matriculation);
}
