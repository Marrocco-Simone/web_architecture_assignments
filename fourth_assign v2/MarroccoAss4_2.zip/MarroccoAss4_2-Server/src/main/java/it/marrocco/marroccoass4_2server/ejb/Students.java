package it.marrocco.marroccoass4_2server.ejb;

import it.marrocco.marroccoass4_2server.entities.StudentEntity;

public interface Students {
    StudentEntity getSingleStudent(int matriculation);
}
