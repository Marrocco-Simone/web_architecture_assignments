package it.marrocco.marroccoass4_2server.ejb;

import it.marrocco.marroccoass4_2server.entities.TeacherEntity;

import java.util.List;

public interface Teachers {
    List<TeacherEntity> getStudentTeachers(int matriculation);
}
