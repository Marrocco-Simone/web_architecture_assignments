package it.marrocco.marroccoass4_2server.ejb;

import it.marrocco.marroccoass4_2server.ServiceLocator;
import it.marrocco.marroccoass4_2server.entities.StudentCourseEntity;
import it.marrocco.marroccoass4_2server.entities.StudentEntity;
import it.marrocco.marroccoass4_2server.entities.TeacherEntity;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.naming.NamingException;
import java.util.List;

@Stateless
@Remote(Facade.class)
public class FacadeEJB implements Facade {
    StudentCourse studentCourseEJB;
    Teachers teachersEJB;
    Students studentsEJB;
    public void ejbCreate() {
        try {
            studentCourseEJB = (StudentCourse) ServiceLocator.getService("java:module/StudentCourseEJB!it.marrocco.marroccoass4_2server.ejb.StudentCourse");
            teachersEJB = (Teachers) ServiceLocator.getService("java:module/TeachersEJB!it.marrocco.marroccoass4_2server.ejb.Teachers");
            studentsEJB = (Students) ServiceLocator.getService("java:module/StudentsEJB!it.marrocco.marroccoass4_2server.ejb.Students");
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public StudentEntity getSingleStudent(int matriculation) {
        System.out.println("getSingleStudent was requested with matriculation " + matriculation);
        return studentsEJB.getSingleStudent(matriculation);
    }

    @Override
    public List<StudentCourseEntity> getStudentCourses(int matriculation) {
        System.out.println("getStudentCourses was requested with matriculation " + matriculation);
        return studentCourseEJB.getStudentCourses(matriculation);
    }

    @Override
    public List<TeacherEntity> getStudentTeachers(int matriculation) {
        System.out.println("getStudentTeachers was requested with matriculation " + matriculation);
        return teachersEJB.getStudentTeachers(matriculation);
    }
}
