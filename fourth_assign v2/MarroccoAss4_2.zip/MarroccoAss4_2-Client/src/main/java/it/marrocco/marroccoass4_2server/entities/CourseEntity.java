package it.marrocco.marroccoass4_2server.entities;

import java.io.Serializable;
import java.util.Objects;

public class CourseEntity implements Serializable {
    private String name;
    private TeacherEntity teacher;

    public CourseEntity() {}
    public CourseEntity(String name, TeacherEntity teacher) {
        this.name = name;
        this.teacher = teacher;
    }


    public String getName() {return name;}
    public void setName(String name) {this.name = name;}

    public TeacherEntity getTeacher() {return teacher;}
    public void setTeacher(TeacherEntity teacher) {this.teacher = teacher;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CourseEntity that = (CourseEntity) o;
        return name.equals(that.name) && teacher.equals(that.teacher);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, teacher);
    }
}
