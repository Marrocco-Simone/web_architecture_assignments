package it.marrocco.marroccoass4_2client.businessDelegate;

import it.marrocco.marroccoass4_2server.entities.StudentCourseEntity;
import it.marrocco.marroccoass4_2server.entities.StudentEntity;
import it.marrocco.marroccoass4_2server.entities.TeacherEntity;
import it.marrocco.marroccoass4_2server.ejb.Facade;

import javax.naming.NamingException;
import java.util.List;

public class BusinessDelegate {
    Facade facadeEJB;
    public BusinessDelegate() {
        try {
            String jndiName = "ejb:/MarroccoAss4_2-Server-1.0-SNAPSHOT/FacadeEJB!it.marrocco.marroccoass4_2server.ejb.Facade";
            facadeEJB = (Facade) ServiceLocator.getService(jndiName);
        } catch (NamingException e) {
            System.out.println("Naming exception: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public StudentEntity getSingleStudent(int matriculation) {
        return facadeEJB.getSingleStudent(matriculation);
    }

    public List<StudentCourseEntity> getStudentCourses(int matriculation) {
        return facadeEJB.getStudentCourses(matriculation);
    }

    public List<TeacherEntity> getStudentTeachers(int matriculation) {
        return facadeEJB.getStudentTeachers(matriculation);
    }
}
