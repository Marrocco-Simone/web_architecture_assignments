package it.marrocco.marroccoass4_2server.entities;

import java.io.Serializable;
import java.util.Objects;

public class TeacherEntity implements Serializable {
    private Integer matriculation;
    private String name;
    private String surname;

    public TeacherEntity() {}
    public TeacherEntity(String name, String surname) {
        System.out.println("tried to change both: "+name+surname);
        this.name = name;
        this.surname = surname;
    }

    public Integer getMatriculation() {return matriculation;}
    public void setMatriculation(Integer matriculation) {
        if (matriculation == null) return;
        this.matriculation = matriculation;
    }

    public String getName() {return name;}
    public void setName(String name) {
        if (name == null) return;
        this.name = name;
    }

    public String getSurname() {return surname;}
    public void setSurname(String surname) {
        if (surname == null) return;
        this.name = surname;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TeacherEntity that = (TeacherEntity) o;
        return matriculation.equals(that.matriculation) && name.equals(that.name) && surname.equals(that.surname);
    }

    @Override
    public int hashCode() {
        return Objects.hash(matriculation, name, surname);
    }
}