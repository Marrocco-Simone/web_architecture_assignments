package it.marrocco.marroccoass4_2client;

import it.marrocco.marroccoass4_2client.businessDelegate.BusinessDelegate;
import it.marrocco.marroccoass4_2server.entities.StudentCourseEntity;
import it.marrocco.marroccoass4_2server.entities.StudentEntity;
import it.marrocco.marroccoass4_2server.entities.TeacherEntity;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "searchMatriculation", value = "/searchMatriculation")
public class SearchMatriculationServlet extends HttpServlet {
    BusinessDelegate bd;

    @Override
    public void init() {
        try {
            bd = new BusinessDelegate();
            System.out.println("Connection working");
        } catch(RuntimeException e) {
            System.out.println("Cannot get connection to server");
        }
    }

    public String formatStudentEntity(StudentEntity s) {
        return "<h1>" + s.getSurname() + " " + s.getName() + " (" + s.getMatriculation() + ")</h1>";
    }

    public String getStudentPageElement(int matriculation) {
        StudentEntity s = bd.getSingleStudent(matriculation);
        if (s == null) return "<h1>Student was not found</h1>";
        String html = formatStudentEntity(s);
        html += "<h2>Courses:</h2>";
        try {
            html += "<ul>";
            List<StudentCourseEntity> sc = bd.getStudentCourses(matriculation);
            if (sc == null) return "<h1>Error getting the Student Courses</h1>";
            for (StudentCourseEntity c : sc) {
                html += "<li>" + c.getCourse().getName();
                if(c.getGrade() != null)
                    html +=  " (grade = " + c.getGrade() + ")";
                html += "</li>";
            }
            html += "</ul>";
        } catch (Exception e ) {
            System.out.println("error: " + e.getMessage());
            html += "<h3>error<h3>";
        }
        return html;
    }

    public String getAdvisoryPageElement(int matriculation) {
        StudentEntity s = bd.getSingleStudent(matriculation);
        if (s == null) return "<h1>Student was not found</h1>";
        String html = formatStudentEntity(s);
        html += "<h2>Advisors:</h2>";
        try {
            html += "<ul>";
            List<TeacherEntity> sc = bd.getStudentTeachers(matriculation);
            if (sc == null) return "<h1>Error getting the Student Teachers</h1>";
            for (TeacherEntity t : sc) {
                html += "<li>" + t.getSurname() + " " + t.getName() + "</li>";
            }
            html += "</ul>";
        } catch (Exception e ) {
            System.out.println("error: " + e.getMessage());
            html += "<h3>error<h3>";
        }
        return html;
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int matriculation;
        try {
            matriculation = Integer.parseInt(request.getParameter("matriculation"));
        } catch (NumberFormatException e) {
            response.sendRedirect("");
            return;
        }
        boolean showStudentPage = request.getParameter("studentPage") != null;
        boolean showAdvisoryPage = request.getParameter("advisoryPage") != null;

        String html = "";
        try {
            if (showStudentPage) html += getStudentPageElement(matriculation);
            if (showAdvisoryPage) html += getAdvisoryPageElement(matriculation);
        } catch (Exception e) {
            System.out.println("Error in fetching data");
            html += "<h1>Error in fetching data</h1>";
            html += "<p>"+e.getMessage()+"</p>";
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Matriculation "+matriculation+"</title></head><body>");
        out.println(html);
        out.println("<a href='index.jsp'>Go back</a>");
        out.println("</body></html>");
        out.close();
    }
}